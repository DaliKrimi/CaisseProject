﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Threading.Tasks;
using WebApplication4.Models;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;


namespace WebApplication4.Controllers
{
    public class articleController : Controller
    { 
    
        public ActionResult Index(string  searching)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            { 
              
                return View(db.Articles.Include(x=>x.IdCatNavigation).Where(x=>x.Name.Contains(searching) || searching==null).ToList());

            }
        }
       
        public IActionResult Info_Art(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                string sql = $"select * from article a , categorie c where ((a.id_cat=c.id_cat) and (a.id_art={id})) ";
                using (var command = new SqlCommand(sql, (SqlConnection)db.Database.GetDbConnection()))
                {
                    db.Database.OpenConnection();

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ViewBag.idart = reader.GetInt32(0);
                            ViewBag.name = reader.GetString(1);
                            ViewBag.prix = reader.GetDouble(5);
                            ViewBag.qte = 1;
                            ViewBag.remise = reader.GetDouble(6);
                            ViewBag.cat = reader.GetInt32(4);
                            ViewBag.qtedisp = reader.GetInt32(3);

                        }
                    }
                }
               
                return View("Indexvendeur");
            }
        }

        public IActionResult Info_Art1( string name)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                string sql = $"select * from article a  where (a.name={name}) ";
                using (var command = new SqlCommand(sql, (SqlConnection)db.Database.GetDbConnection()))
                {
                    db.Database.OpenConnection();

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ViewBag.idart = reader.GetInt32(0);
                            ViewBag.name = reader.GetString(1);
                            ViewBag.prix = reader.GetDouble(5);
                            ViewBag.qte = 1;
                            ViewBag.remise = reader.GetDouble(6);
                            ViewBag.cat = reader.GetInt32(4);
                            ViewBag.qtedisp = reader.GetInt32(3);

                        }
                    }
                }

                return View("Indexvendeur");
            }
        }
        public ActionResult liste_prod ()
        {
            using (Caisse_ProjectContext db=new Caisse_ProjectContext())
            {
                var data = db.Articles.Include(x=>x.IdCatNavigation).ToList();
                return PartialView("_prod",data);
            }
        }
        public ActionResult liste_prod_fact()
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.ProduitFacts.ToList();
                return PartialView("_prodfact", data);
            }
        }
        public ActionResult liste_autre_produit()
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.AutreProduits.ToList();
                return PartialView("_autreproduit", data);
            }

        }

        public IActionResult DeleteAll ()
        {
            var d = DateTime.Now;
            using (Caisse_ProjectContext db=new Caisse_ProjectContext())
            {
                var data=db.Monetisations.Where(x => x.DateMon == d).FirstOrDefault();
                var data1 = db.ProduitFacts.Where(x => x.PrixTot != 0).FirstOrDefault();
                var som = db.ProduitFacts.Sum(x => x.PrixTot);
                var i = db.ProduitFacts.Count();
                if (data != null)
                { 
                    data.Montant = data.Montant + som;
                    db.ProduitFacts.RemoveRange(db.ProduitFacts);
                    db.SaveChanges();
                }
                else
                {
                    Monetisation mon = new Monetisation()
                    {
                        Id = i + 1,
                        DateMon = d,
                        Montant = som,
                    };
                    db.Monetisations.AddRange(mon);
                    db.ProduitFacts.RemoveRange(db.ProduitFacts);
                    db.SaveChanges();
                }
                return RedirectToAction(nameof(IndexVendeur));
            }
        }
        public ActionResult DeleteProd(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.ProduitFacts.Where(x => x.IdArt == id).FirstOrDefault();
                    if (data != null)
                    {
                        db.ProduitFacts.Remove(data);
                        var data1 = db.Articles.Where(x => x.IdArt == id).FirstOrDefault();
                        data1.QteDisp = data1.QteDisp + data.QteDisp;
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(IndexVendeur));
                }
                catch
                {
                    return View("Error");
                }
            }
        }
        [HttpPost]
        public ActionResult Add_product (ProduitFact article )
        {
            using (Caisse_ProjectContext db=new Caisse_ProjectContext ())
            {
                var  d = db.ProduitFacts.Find(article.IdArt);
                if (d == null)
                {
                    var data = db.Articles.Where(x => x.IdArt == article.IdArt).FirstOrDefault();
                    if (data.QteDisp > 10)
                    {
                        if (data.QteDisp > article.QteDisp+10)
                        {
                            db.ProduitFacts.Add(article);
                            var da=db.Articles.Where(x => x.IdArt == article.IdArt).FirstOrDefault();
                            da.QteDisp = da.QteDisp - article.QteDisp;
                            db.SaveChanges();
                        }
                        else
                        {
                            ViewData["stock"] = data.QteDisp - 11;
                            return View(nameof(IndexVendeur));
                        }
                    }
                    else
                    {
                        ViewData["epuise"] = 1;
                        return View(nameof(IndexVendeur));
                    }
                }
                else
                {
                    ViewData["exixting"] = 1;
                    return View(nameof(IndexVendeur));
                }
                return RedirectToAction(nameof(IndexVendeur));
            }
        }

        public ActionResult Details(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Articles.Include(x=>x.IdCatNavigation).Where(x => x.IdArt == id).FirstOrDefault();
                return View(data);
            }
        }
       public ActionResult IndexVendeur ()
        {
            return View();
        }

      public IActionResult SommeTotale()
        {
            using (Caisse_ProjectContext db=new Caisse_ProjectContext ())
            {
                var data = db.ProduitFacts.Sum(x => x.PrixTot);
                ViewData["Sommetot"] = data;
                return PartialView("_sommetot", ViewData["sommetot"]);
            }
        }
 
        public ActionResult Create(int id = 0)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                Article art = new Article();
                var lastarticle = db.Articles.OrderByDescending(c => c.IdArt).FirstOrDefault();
                var items = db.Categories.ToList();
                ViewBag.IdCat = new SelectList(items, "IdCat", "Designation");
                if (id != 0)
                {
                    art = db.Articles.Where(x => x.IdArt == id).FirstOrDefault<Article>();
                }
                else if (lastarticle == null)
                {
                    art.IdArt = 1;
                }
                else
                {
                    art.IdArt = (lastarticle.IdArt + 1);

                }
                return View(art);
            }
        }

  
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Article article)
        {


            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                if (ModelState.IsValid)
                {
                    db.Articles.Add(article);
                    db.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }

                return View();
            }
        }
       
      /*  [HttpGet]
        public ActionResult editing ()
        {
            using (Caisse_ProjectContext db=new Caisse_ProjectContext())
            {
                var data = db.Articles.Include(x=>x.IdCatNavigation).ToList();
                return View(data);
            }
        }*/

  
        [HttpGet]
        public ActionResult Edit(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Articles.Where(x => x.IdArt == id).FirstOrDefault();
                var items = db.Categories.ToList();
                ViewBag.IdCat = new SelectList(items, "IdCat", "Designation");
                return View(data);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Article article)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.Articles.Where(x => x.IdArt == id).FirstOrDefault();
                    if (data != null)
                    {
                        data.Name = article.Name;
                        data.DateExp = article.DateExp;
                        data.QteDisp = article.QteDisp;
                        data.IdCat = article.IdCat;
                        data.Prix = article.Prix;
                        data.Remise = article.Remise;
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("error");
                }
            }
        }
       
       /* [HttpGet]
        public ActionResult Delete ()
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Articles.Include(x => x.IdCatNavigation).ToList();
                return View(data);
            }
        }*/
        public ActionResult Delete(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                   var data = db.Articles.Where(x => x.IdArt == id).FirstOrDefault();
                    if (data != null)
                    {
                        db.Articles.Remove(data);
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("Error");
                }
            }
        }
    }
}    
