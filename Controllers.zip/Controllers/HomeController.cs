﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult HomePage()
        {
            return View();
        }
        public IActionResult Login_Page ()
        {
            return View();
        }
        public IActionResult IndexVendeur ()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login_Page ([Bind] Admin admin )
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                if (ModelState.IsValid)
                {
                    int res = db.login_check(admin);
                    if (res == 1)
                    {
                        return RedirectToAction(nameof(Index));
                    }
                    else
                        return RedirectToAction(nameof(error_login));
                }
                else
                {
                    return View();
                }
            }
        }
        public IActionResult error_login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult error_login([Bind] Admin admin)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                if (ModelState.IsValid)
                {
                    int res = db.login_check(admin);
                    if (res == 1)
                    {
                        return RedirectToAction(nameof(Index));
                    }
                    else
                        return RedirectToAction(nameof(error_login));
                }
                else
                    return View();
            }
        }
        public IActionResult vendeur_Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult vendeur_Login([Bind] Vendeur vendeur)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                if (ModelState.IsValid)
                {
                    int res = db.vendeur_login(vendeur);
                    if (res == 1)
                    {
                        return RedirectToAction("IndexVendeur", "article"); 
                    }
                    else
                        return RedirectToAction(nameof(error_Login_vendeur));
                }
                else
                {
                    return View();
                }
            }
        }
        public IActionResult error_Login_vendeur()
        {
            return View();
        }
        [HttpPost]
        public IActionResult error_Login_vendeur([Bind] Vendeur vendeur)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                if (ModelState.IsValid)
                {
                    int res = db.vendeur_login(vendeur);
                    if (res == 1)
                    {
                        return RedirectToAction("Liste_Categorie", "article");
                    }
                    else
                        return RedirectToAction(nameof(error_Login_vendeur));
                }
                else
                    return View();
            }
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
