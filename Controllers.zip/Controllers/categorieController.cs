﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class categorieController : Controller
    {
        public ActionResult Index(string searching)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                
                return View(db.Categories.Where(x => x.Designation.Contains(searching) || searching == null).ToList());
            }
        }
        public ActionResult Index_Vendeur ()
        {
            return View("IndexVendeur");
        }
        public ActionResult Liste_Categorie()
        {
            DataTable dt = new DataTable();
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Categories.ToList();
                if (data.Count() != 0)
                    ViewBag.data = data;
                else
                    ViewBag.data = "errror";
                return View("../article/IndexVendeur");
            }
        }

     
        public ActionResult Details(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Categories.Where(x => x.IdCat == id).FirstOrDefault();
                if (data != null)
                    return View(data);
                else
                    return View("notfound");
            }
        }

   
        [HttpGet]
        public ActionResult Create(int id=0)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                Categorie cat = new Categorie();
                var lastcategorie = db.Categories.OrderByDescending(c => c.IdCat).FirstOrDefault();
                if (id != 0)
                {
                    cat = db.Categories.Where(x => x.IdCat == id).FirstOrDefault<Categorie>();
                }
                else if (lastcategorie == null)
                {
                    cat.IdCat = 1;
                }
                else
                {
                    cat.IdCat = (lastcategorie.IdCat + 1);

                }
                return View(cat);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Categorie categorie)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                if (ModelState.IsValid)
                {
                    db.Categories.Add(categorie);
                    db.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                else
                    return View();
                
            }
        }
        /*[HttpGet]
        public ActionResult editing ()
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Categories.ToList();
                return View(data);
            }
        }*/

      
        [HttpGet]
        public ActionResult Edit(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Categories.Where(x => x.IdCat == id).FirstOrDefault();
                return View(data);
            }
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Categorie categorie)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.Categories.Where(x => x.IdCat == id).FirstOrDefault();
                    if (data != null)
                    {
                        data.Designation = categorie.Designation;
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("Error");
                }
            }
        }
       /* [HttpGet ]
        public ActionResult Delete ()
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Categories.ToList();
                return View(data);
            }
        }*/
        public ActionResult Delete(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.Categories.Where(x => x.IdCat == id).FirstOrDefault();
                    if (data != null)
                    {
                        db.Categories.Remove(data);
                        db.SaveChanges();
                    }
                        return RedirectToAction(nameof(Index));
                    
                }
                catch
                {
                    return View("Error");
                }
            }
        }
    }
}
