﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class produitfactureController : Controller
    {
        // GET: produitfactureController
        public ActionResult Index()
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.ProduitFactures.Include(x => x.IdArtNavigation).Include(x => x.IdFactNavigation).ToList();
                return View(data);
            }
        }

        // GET: produitfactureController/Details/5
        public ActionResult Details(int idfact , int idart )
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.ProduitFactures.FromSqlInterpolated($"Select * from produit_facture where id_fact={idfact} and  id_art={idart} ").FirstOrDefault();
                return View(data);
            }
        }

        // GET: produitfactureController/Create
        public ActionResult Create()
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var item1 = db.Factures.ToList();
                ViewBag.IdFact = new SelectList(item1, "IdFact", "IdFact");
                var item2 = db.Articles.ToList();
                ViewBag.IdArt = new SelectList(item2, "IdArt", "Name");
                return View();
            }
        }

        // POST: produitfactureController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(ProduitFacture produitfacture)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {

                if (ModelState.IsValid)
                {
                    db.ProduitFactures.Add(produitfacture);
                    db.SaveChanges();


                    return RedirectToAction(nameof(Index));
                }
                else
                    return View();
            }
        }

        // GET: produitfactureController/Edit/5
        public ActionResult Edit(int idfact , int idart)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.ProduitFactures.FromSqlInterpolated($"Select * from produit_facture where id_fact={idfact} and  id_art={idart} ").FirstOrDefault();
                var item1 = db.Factures.ToList();
                ViewBag.IdFact = new SelectList(item1, "IdFact", "IdFact");
                var item2 = db.Articles.ToList();
                ViewBag.IdArt = new SelectList(item2, "IdArt", "Name");
                return View(data);
            }
        }

        // POST: produitfactureController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(ProduitFacture produit )
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.ProduitFactures.Where(x => x.IdFact == produit.IdFact && x.IdArt == produit.IdArt).FirstOrDefault();
                    if(data!=null)
                    {
                        data.IdArt = produit.IdArt;
                        data.IdFact = produit.IdFact;
                        data.Qte = produit.Qte;
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("error");
                }
            }
        }
        public ActionResult Delete(int idfact , int idart )
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.ProduitFactures.Where(x => x.IdFact == idfact && x.IdArt == idart).FirstOrDefault();
                    if(data!=null)
                    {
                        db.ProduitFactures.Remove(data);
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("error");
                }
            }
        }
    }
}
