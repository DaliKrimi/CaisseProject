﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class fournisseurController : Controller
    {
        // GET: fournisseurController
        public ActionResult Index(string searching )
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                return View(db.Fournisseurs.Where(x => x.Name.Contains(searching) || searching == null).ToList());
            }
        }

        // GET: fournisseurController/Details/5
        public ActionResult Details(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Fournisseurs.Where(x => x.IdFour == id).FirstOrDefault();
                if (data != null)
                    return View(data);
                else
                    return View("notfound");
            }
        }

        // GET: fournisseurController/Create
        public ActionResult Create(int id=0)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                Fournisseur fournisseur = new Fournisseur();
                var lastfournisseur = db.Fournisseurs.OrderByDescending(c => c.IdFour).FirstOrDefault();
                if (id != 0)
                {
                    fournisseur = db.Fournisseurs.Where(x => x.IdFour == id).FirstOrDefault<Fournisseur>();
                }
                else if (lastfournisseur == null)
                {
                    fournisseur.IdFour = 1;
                }
                else
                {
                    fournisseur.IdFour = (lastfournisseur.IdFour + 1);

                }
                return View(fournisseur);
            }

        }

        // POST: fournisseurController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Fournisseur fournisseur)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                if (ModelState.IsValid)
                {
                    db.Fournisseurs.Add(fournisseur);
                    db.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                else
                    return View();
             }
        }
       /* [HttpGet]
        public ActionResult editing ()
        {
            using (Caisse_ProjectContext db=new Caisse_ProjectContext())
            {
                var data = db.Fournisseurs.ToList();
                return View(data);
            }

        }*/

        // GET: fournisseurController/Edit/5
        public ActionResult Edit(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Fournisseurs.Where(x => x.IdFour == id).FirstOrDefault();
                return View(data);
            }
        }

        // POST: fournisseurController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Fournisseur fournisseur)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.Fournisseurs.Where(x => x.IdFour == id).FirstOrDefault();
                    if (data != null)
                    {
                        data.Name = fournisseur.Name;
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("error");
                }
            }
        }
      /*  [HttpGet]
        public ActionResult deleting ()
        {
            using (Caisse_ProjectContext db=new Caisse_ProjectContext())
            {
                var data = db.Fournisseurs.ToList();
                return View(data);
            }
        }*/
        public ActionResult Delete(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.Fournisseurs.Where(x => x.IdFour == id).FirstOrDefault();
                    if (data != null)
                    {
                        db.Fournisseurs.Remove(data);
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("error");
                }
            }
        }
    }
}
