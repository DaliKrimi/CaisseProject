﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Threading.Tasks;
using WebApplication4.Models;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;

namespace WebApplication4.Controllers
{
    public class autreproduitController : Controller
    {
        // GET: autreproduitController
        public ActionResult Index(string searching )
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                return View(db.AutreProduits.Where(x => x.Nom.Contains(searching) || searching == null).ToList());

            }
        }
       
        // GET: autreproduitController/Details/5
        public ActionResult Details(string nom )
        {
            using(Caisse_ProjectContext db = new Caisse_ProjectContext ())
            {
                var data = db.AutreProduits.Where(x => x.Nom == nom).FirstOrDefault();
                if (data != null)
                {
                    return View(data);
                }
                else
                    return View("error");
            }
        }

        // GET: autreproduitController/Create
        public ActionResult Create()
        {
            return View();
        }

       

        // POST: autreproduitController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(AutreProduit autreProduit)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    db.AutreProduits.Add(autreProduit);
                    db.SaveChanges();
                    return RedirectToAction(nameof(Index));
                    
                }
                catch
                {
                    return View("error");
                }
            }
        }

        // GET: autreproduitController/Edit/5
        public ActionResult Edit(string  id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.AutreProduits.Where(x => x.Nom == id).FirstOrDefault();
                return View(data);
            }
        }

        // POST: autreproduitController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit( AutreProduit autreproduit)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.AutreProduits.Where(x => x.Nom == autreproduit.Nom).FirstOrDefault();
                    if (data != null)
                    {
                        data.Nom = autreproduit.Nom;
                        data.Prix = autreproduit.Prix;
                        data.QteQisp = autreproduit.QteQisp;
                        data.Remise = autreproduit.Remise;
                        data.UniteMesure = autreproduit.UniteMesure;
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("error");
                }
            }
        }
    

        // GET: autreproduitController/Delete/5
        public ActionResult Delete(string  id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.AutreProduits.Where(x => x.Nom == id).FirstOrDefault();
                    if (data != null)
                    {
                        db.AutreProduits.Remove(data);
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("error");
                }
            }
        }

       
    }
}
