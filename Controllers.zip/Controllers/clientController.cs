﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class clientController : Controller
    {
        // GET: clientController
        public ActionResult Index(string searching )
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
           
            return View(db.Clients.Where(x=>x.Firstname.Contains(searching)||searching==null).ToList());
        }
    }
       /* [HttpGet]
        public ActionResult recherche_clt ()
        {
            return View();
        }*/
        // GET: clientController/Details/5
        public ActionResult Details(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Clients.Where(x => x.IdClt == id).FirstOrDefault();
                if (data != null)
                    return View(data);
                else
                    return View("notfound");
            }
        }

        // GET: clientController/Create
        [HttpGet]
        public ActionResult Create(int id=0)
        {

            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                Client clt = new Client();
                var lastclient = db.Clients.OrderByDescending(c => c.IdClt).FirstOrDefault();
                if (id != 0)
                {
                    clt = db.Clients.Where(x => x.IdClt == id).FirstOrDefault<Client>();
                }
                else if (lastclient == null)
                {
                    clt.IdClt = 1;
                }
                else
                {
                    clt.IdClt = (lastclient.IdClt + 1);

                }
                return View(clt);
            }
        }

        // POST: clientController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Client client)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                if (ModelState.IsValid)
                {
                    db.Clients.Add(client);
                    db.SaveChanges();

                    return RedirectToAction(nameof(Index));
                }
                else
                    return View();
            }
        }
       /* [HttpGet]
        public ActionResult editing ()
        {
            using (Caisse_ProjectContext db=new Caisse_ProjectContext())
            {
                var data = db.Clients.ToList();
                return View(data);
            }
        }*/
        // GET: clientController/Edit/5
        public ActionResult Edit(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Clients.Where(x => x.IdClt == id).FirstOrDefault();
                return View(data);
            }
        }

        // POST: clientController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit( Client client )
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.Clients.Where(x => x.IdClt == client.IdClt).FirstOrDefault();
                    if (data !=null )
                    {
                        data.Firstname = client.Firstname;
                        data.Lastname = client.Lastname;
                        data.NumCarte = client.NumCarte;
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("Error");
                }
            }
        }
      /*  [HttpGet]
        public ActionResult Delete()
        {
            using(Caisse_ProjectContext db=new Caisse_ProjectContext())
            {
                var data = db.Clients.ToList();
                return View(data);
            }
        }*/

        public ActionResult Delete(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.Clients.Where(x => x.IdClt == id).FirstOrDefault();
                    if (data != null)
                    {
                        db.Clients.Remove(data);
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("Error");
                }
            }
        }
    }
}
