﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class vendeurController : Controller
    {
        // GET: vendeurController
        public ActionResult Index(string searching )
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                return View(db.Vendeurs.Where(x => x.Fullname.Contains(searching) || searching == null).ToList());
            }
        }
       
        // GET: vendeurController/Details/5
        public ActionResult Details(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Vendeurs.Where(x => x.IdVendeur == id).FirstOrDefault();
                if (data != null)
                    return View(data);
                else
                    return View("notfound");
            }
        }
        // GET: vendeurController/Create
        [HttpGet]
        public ActionResult Create(int id=0)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                Vendeur vendeur = new Vendeur();
                var lastvendeur = db.Vendeurs.OrderByDescending(c => c.IdVendeur).FirstOrDefault();
                if (id != 0)
                {
                    vendeur = db.Vendeurs.Where(x => x.IdVendeur== id).FirstOrDefault<Vendeur>();
                }
                else if (lastvendeur  == null)
                {
                    vendeur.IdVendeur= 1;
                }
                else
                {
                    vendeur.IdVendeur= (lastvendeur.IdVendeur+ 1);

                }
                return View(vendeur);
            }
        }

        // POST: vendeurController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Vendeur vendeur)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                if (ModelState.IsValid)
                {
                    db.Vendeurs.Add(vendeur);
                    db.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                else
                    return View(); 
            }
        }
        /*[HttpGet]
        public ActionResult editing ()
        {
            using (Caisse_ProjectContext db=new Caisse_ProjectContext())
            {
                var data = db.Vendeurs.ToList();
                return View(data);
            }
        }*/
        // GET: vendeurController/Edit/5
        public ActionResult Edit(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Vendeurs.Where(x => x.IdVendeur == id).FirstOrDefault();
                return View(data);
            }
        }

        // POST: vendeurController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Vendeur vendeur)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.Vendeurs.Where(x => x.IdVendeur == vendeur.IdVendeur).FirstOrDefault();
                    if (data != null)
                    {
                        data.Fullname = vendeur.Fullname;
                        data.Mdp = vendeur.Mdp;
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("error");
                }
            }
        }
      /*  [HttpGet]
        public ActionResult deleting ()
        {
            using (Caisse_ProjectContext db=new Caisse_ProjectContext())
            {
                var data = db.Vendeurs.ToList();
                return View(data);
            }
        }*/
        public ActionResult Delete(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.Vendeurs.Where(x => x.IdVendeur == id).FirstOrDefault();
                    if (data != null)
                    {
                        db.Vendeurs.Remove(data);
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("error");
                }
            }
        }
    }
}
