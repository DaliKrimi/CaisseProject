﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class factureController : Controller
    {
        public ActionResult Index()
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Factures.Include(x=>x.IdCltNavigation).Include(x=>x.IdVendeurNavigation).ToList();
                return View(data);
            }
        }

        // GET: factureController/Details/5
        public ActionResult Details(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Factures.Include(x => x.IdCltNavigation).Include(x => x.IdVendeurNavigation).Where(x => x.IdFact == id).FirstOrDefault();
                if (data != null)
                    return View(data);
                else
                    return View("notfound");

            }
        }

        // GET: factureController/Create
        public ActionResult Create(int id = 0)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                Facture facture = new Facture();
                var lastfacture = db.Factures.OrderByDescending(c => c.IdFact).FirstOrDefault();
                var item1 = db.Vendeurs.ToList();
                ViewBag.IdVendeur = new SelectList(item1, "IdVendeur", "Fullname");
                var item2 = db.Clients.ToList();
                ViewBag.IdClt = new SelectList(item2, "IdClt", "Firstname");
                if (id != 0)
                {
                    facture = db.Factures.Where(x => x.IdFact == id).FirstOrDefault<Facture>();
                }
                else if (lastfacture == null)
                {
                    facture.IdFact = 1;
                }
                else
                {
                    facture.IdFact = (lastfacture.IdFact + 1);

                }
                return View(facture);
            }
        }

        // POST: factureController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Facture facture)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                if (ModelState.IsValid)
                {
                    db.Factures.Add(facture);
                    db.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                else
                    return View();
             }
        }
      /*  [HttpGet]
        public ActionResult editing ()
        {
            using (Caisse_ProjectContext db=new Caisse_ProjectContext ())
            {
                var data = db.Factures.Include(x => x.IdCltNavigation).Include(x => x.IdVendeurNavigation).ToList();
                return View(data);
            }
        }*/

        // GET: factureController/Edit/5
        public ActionResult Edit(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.Factures.Where(x => x.IdFact == id).FirstOrDefault();
                var item1 = db.Vendeurs.ToList();
                ViewBag.IdVendeur = new SelectList(item1, "IdVendeur", "Fullname");
                var item2 = db.Clients.ToList();
                ViewBag.IdClt = new SelectList(item2, "IdClt", "Firstname");
                return View(data);
            }
        }

        // POST: factureController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Facture facture)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.Factures.Where(x => x.IdFact == facture.IdFact).FirstOrDefault();
                    if (data!=null)
                    {
                        data.DateFact = facture.DateFact;
                        data.Total = facture.Total;
                      
                        data.IdClt = facture.IdClt;
                        data.IdVendeur = facture.IdVendeur;
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View();
                }
            }
        }
       /* [HttpGet]
        public ActionResult deleting ()
        {
            using(Caisse_ProjectContext db=new Caisse_ProjectContext())
            {
                var data = db.Factures.Include(x => x.IdCltNavigation).Include(x => x.IdVendeurNavigation).ToList();
                return View(data);
            }
        }*/
        public ActionResult Delete(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.Factures.Where(x => x.IdFact == id).FirstOrDefault();
                    if (data != null )
                    {
                        db.Factures.Remove(data);
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("error");
                }
            }
        }
    }
}
