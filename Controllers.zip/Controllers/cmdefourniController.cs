﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class cmdefourniController : Controller
    {
      
        public ActionResult Index()
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.CmdeFournis.Include(x=>x.IdFourNavigation).ToList();
                return View(data);
            }
        }

       
        public ActionResult Details(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.CmdeFournis.Include(x => x.IdFourNavigation).Where(x => x.IdCmd == id).FirstOrDefault();
                if (data != null)
                    return View(data);
                else
                    return View("notfound");
            }
        }

       
        public ActionResult Create(int id=0)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                CmdeFourni cmde = new CmdeFourni();
                var lastcmde = db.CmdeFournis.OrderByDescending(c => c.IdCmd).FirstOrDefault();
                var items = db.Articles.ToList();
                ViewBag.IdArt = new SelectList(items, "IdArt", "Name");
                var items1 = db.Fournisseurs.ToList();
                ViewBag.IdFour = new SelectList(items1, "IdFour", "Name");
                if (id != 0)
                {
                    cmde = db.CmdeFournis.Where(x => x.IdCmd== id).FirstOrDefault<CmdeFourni>();
                }
                else if (lastcmde == null)
                {
                    cmde.IdCmd = 1;
                }
                else
                {
                    cmde.IdCmd = (lastcmde.IdCmd + 1);

                }
                return View(cmde);
            }
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(CmdeFourni cmde)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                if (ModelState.IsValid)
                {
                    db.CmdeFournis.Add(cmde);
                    var data = db.Articles.Where(x => x.IdArt == cmde.IdArt).FirstOrDefault();
                    data.QteDisp = (int)(data.QteDisp+ cmde.Qte);
                    db.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                else
                    return View();
            }
        }
      /*  [HttpGet]
        public ActionResult editing ()
        {
            using(Caisse_ProjectContext db=new Caisse_ProjectContext ())
            {
                var data = db.CmdeFournis.Include(x => x.IdFourNavigation).ToList();
                return View(data);
            }
        }*/
       
        public ActionResult Edit(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                var data = db.CmdeFournis.Where(x => x.IdCmd == id).FirstOrDefault();
                var items = db.Articles.ToList();
                ViewBag.IdArt = new SelectList(items, "IdArt", "Name");
                var items1 = db.Fournisseurs.ToList();
                ViewBag.IdFour = new SelectList(items1, "IdFour", "Name");
                return View(data);
            }
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, CmdeFourni cmde)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.CmdeFournis.Where(x => x.IdCmd == id).FirstOrDefault();
                    var data1 = db.Articles.Where(x => x.IdArt == data.IdArt).FirstOrDefault();
                    if(data != null )
                    {
                        data1.QteDisp = (int)(data1.QteDisp - data.Qte);
                        data.Qte = cmde.Qte;
                        data.IdArt = cmde.IdArt;
                        data.IdFour = cmde.IdFour;
                        data1.QteDisp = (int)(data1.QteDisp + data.Qte);
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("error");
                }
            }
        }
       /* [HttpGet]
        public ActionResult deleting ()
        {
            using (Caisse_ProjectContext db=new Caisse_ProjectContext())
            {
                var data = db.CmdeFournis.Include(x => x.IdFourNavigation).ToList();
                return View(data);
            }
        }*/
        public ActionResult Delete(int id)
        {
            using (Caisse_ProjectContext db = new Caisse_ProjectContext())
            {
                try
                {
                    var data = db.CmdeFournis.Where(x => x.IdCmd == id).FirstOrDefault();
                    var data1 = db.Articles.Where(x => x.IdArt == data.IdArt).FirstOrDefault();
                    if (data != null )
                    {
                        db.CmdeFournis.Remove(data);
                        data1.QteDisp = ((int)((int)data1.QteDisp - data.Qte));
                        db.SaveChanges();
                    }

                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("error");
                }
            }
        }
    }
}
