﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class monetisationController : Controller
    {
        // GET: monetisationController
        public ActionResult Index()
        {
                using (Caisse_ProjectContext db = new Caisse_ProjectContext())
                {
                    var data = db.Monetisations.ToList();
                    return View(data);

                }
            
        }

        // GET: monetisationController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: monetisationController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: monetisationController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: monetisationController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: monetisationController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: monetisationController/Delete/5
        public ActionResult Delete(int id)
        {
            using (Caisse_ProjectContext db =new Caisse_ProjectContext())
            {
                try
                {
                   
                    var data = db.Monetisations.Where(x => x.Id == id).FirstOrDefault();
                    if (data != null)
                    {
                        db.Monetisations.Remove(data);
                        db.SaveChanges();
                    }
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View("Error");
                }

            }
        }

        // POST: monetisationController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
