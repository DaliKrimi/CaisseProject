﻿
/*    $("#list").click(function () {
        var data = $("#list").val();
        alert(data);
        $.ajax({
        url: '@Url.Action("Liste_Article", "articleController")',
            type: 'GET',
            data: {idcat: data },
            success: function (result) {
        $("#product").html(result);
            }
        });
    });*/


/*$(document).ready(function fct() {

    $("#list").click(function () {
        var data = $("#list").val();
        var url = '@Url.Action("_Liste_Article")';
        alert(data);
        $("#product").load(url, "2",
            function (responseText, textStatus, XMLHttprequest) {

            }
        );
    });

});*/

