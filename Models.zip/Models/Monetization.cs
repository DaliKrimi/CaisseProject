﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication4.Models
{
    public class Monetisation
    {

        public int Id { get; set; }
        public DateTime DateMon { get; set; }
        public double  Montant { get; set; }
    }
}
