﻿using System;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace WebApplication4.Models
{
    public partial class Caisse_ProjectContext : DbContext
    {
        public Caisse_ProjectContext()
        {
        }

        public int login_check (Admin admin )
        {
            using(Caisse_ProjectContext db=new Caisse_ProjectContext())
            {
                
                SqlCommand com = new SqlCommand("login", (SqlConnection)db.Database.GetDbConnection());
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@username", admin.Username);
                com.Parameters.AddWithValue("@password", admin.Password);
                SqlParameter login_para = new SqlParameter();
                login_para.ParameterName = "@IsValid";
                login_para.SqlDbType = System.Data.SqlDbType.Bit;
                login_para.Direction = System.Data.ParameterDirection.Output;
                db.Database.OpenConnection();
                com.Parameters.Add(login_para);
                com.ExecuteNonQuery();
                int res = Convert.ToInt32(login_para.Value);
                return res; 
            }
        }
        public int vendeur_login (Vendeur vendeur )
        {
            using(Caisse_ProjectContext db=new Caisse_ProjectContext())
            {
                SqlCommand com = new SqlCommand("v_login", (SqlConnection)db.Database.GetDbConnection());
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@Fullname", vendeur.Fullname);
                com.Parameters.AddWithValue("@Mdp", vendeur.Mdp);
                SqlParameter login_para = new SqlParameter();
                login_para.ParameterName = "@IsValid";
                login_para.SqlDbType = System.Data.SqlDbType.Bit;
                login_para.Direction = System.Data.ParameterDirection.Output;
                db.Database.OpenConnection();
                com.Parameters.Add(login_para);
                com.ExecuteNonQuery();
                int res = Convert.ToInt32(login_para.Value);
                return res;

            }
        }
        public Caisse_ProjectContext(DbContextOptions<Caisse_ProjectContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Admin> Admins { get; set; }
        public virtual DbSet<Article> Articles { get; set; }
        public virtual DbSet<AutreProduit> AutreProduits { get; set; }
        public virtual DbSet<Categorie> Categories { get; set; }
        public virtual DbSet<Client> Clients { get; set; }
        public virtual DbSet<CmdeFourni> CmdeFournis { get; set; }
        public virtual DbSet<Facture> Factures { get; set; }
        public virtual DbSet<Fournisseur> Fournisseurs { get; set; }
        public virtual DbSet<ProduitFacture> ProduitFactures { get; set; }
        public virtual DbSet<ProduitFact> ProduitFacts { get; set; }
        public virtual DbSet<Monetisation> Monetisations { get; set; }
        public virtual DbSet<Vendeur> Vendeurs { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=LAPTOP-R38H3PQK\\SQLEXPRESS;Database=Caisse_Project;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "French_CI_AS");

            modelBuilder.Entity<Admin>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("admin");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("password");

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("username");
            });

            modelBuilder.Entity<Article>(entity =>
            {
                entity.HasKey(e => e.IdArt);

                entity.ToTable("article");

                entity.Property(e => e.IdArt)
                    .ValueGeneratedNever()
                    .HasColumnName("id_art");

                entity.Property(e => e.DateExp)
                    .HasColumnType("date")
                    .HasColumnName("date_exp");

                entity.Property(e => e.IdCat).HasColumnName("id_cat");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("name");
                entity.Property(e => e.Remise).HasColumnName("remise");

                entity.Property(e => e.QteDisp).HasColumnName("qte_disp");

                entity.HasOne(d => d.IdCatNavigation)
                    .WithMany(p => p.Articles)
                    .HasForeignKey(d => d.IdCat)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_article_categorie");
            });


            modelBuilder.Entity<AutreProduit>(entity =>
            {
                entity.HasKey(e => e.Nom);

                entity.ToTable("AutreProduit");

                entity.Property(e => e.Nom)
                    .ValueGeneratedNever()
                    .HasColumnName("nom");

                entity.Property(e => e.QteQisp)
                    
                    .HasColumnName("qte_disp");

                

                entity.Property(e => e.UniteMesure)
                    
                    .HasColumnName("unite_mesure");
                entity.Property(e => e.Remise).HasColumnName("remise");

                entity.Property(e => e.Prix).HasColumnName("prix");

                
            });

            modelBuilder.Entity<ProduitFact>(entity =>
            {
                entity.HasKey(e => e.IdArt);

                entity.ToTable("ProduitFact");

                entity.Property(e => e.IdArt)
                    .ValueGeneratedNever()
                    .HasColumnName("id_art");

                entity.Property(e => e.DateExp)
                    .HasColumnType("date")
                    .HasColumnName("date_exp");

                entity.Property(e => e.IdCat).HasColumnName("id_cat");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("name");
                entity.Property(e => e.Remise).HasColumnName("remise");

                entity.Property(e => e.QteDisp).HasColumnName("qte_disp");
                entity.Property(e => e.PrixTot).HasColumnName("prix_tot");

            });

            modelBuilder.Entity<Categorie>(entity =>
            {
                entity.HasKey(e => e.IdCat);

                entity.ToTable("categorie");

                entity.Property(e => e.IdCat)
                    .ValueGeneratedNever()
                    .HasColumnName("id_cat");

                entity.Property(e => e.Designation)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("designation");
            });

            modelBuilder.Entity<Client>(entity =>
            {
                entity.HasKey(e => e.IdClt)
                    .HasName("PK__client__56642C08DE20934E");

                entity.ToTable("client");

                entity.Property(e => e.IdClt)
                    .ValueGeneratedNever()
                    .HasColumnName("Id_clt");

                entity.Property(e => e.Firstname)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("firstname");

                entity.Property(e => e.Lastname)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("lastname");

                entity.Property(e => e.NumCarte).HasColumnName("num_carte");
            });

            modelBuilder.Entity<CmdeFourni>(entity =>
            {
                entity.HasKey(e => e.IdCmd);

                entity.ToTable("cmde_fourni");

                entity.Property(e => e.IdCmd)
                    .ValueGeneratedNever()
                    .HasColumnName("id_cmd");

                entity.Property(e => e.IdArt).HasColumnName("id_art");

                entity.Property(e => e.IdFour).HasColumnName("id_four");

                entity.Property(e => e.Qte)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("qte");

              

                entity.HasOne(d => d.IdFourNavigation)
                    .WithMany(p => p.CmdeFournis)
                    .HasForeignKey(d => d.IdFour)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_cmde_fourni_fournisseur");
            });

            modelBuilder.Entity<Facture>(entity =>
            {
                entity.HasKey(e => e.IdFact);

                entity.ToTable("facture");

                entity.Property(e => e.IdFact)
                    .ValueGeneratedNever()
                    .HasColumnName("id_fact");

                entity.Property(e => e.DateFact)
                    .HasColumnType("date")
                    .HasColumnName("date_fact");

                entity.Property(e => e.IdClt).HasColumnName("Id_clt");

                entity.Property(e => e.IdVendeur).HasColumnName("id_vendeur");

                

                entity.Property(e => e.Total).HasColumnName("total");

                entity.HasOne(d => d.IdCltNavigation)
                    .WithMany(p => p.Factures)
                    .HasForeignKey(d => d.IdClt)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_facture_client");

                entity.HasOne(d => d.IdVendeurNavigation)
                    .WithMany(p => p.Factures)
                    .HasForeignKey(d => d.IdVendeur)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_facture_vendeurs");
            });

            modelBuilder.Entity<Fournisseur>(entity =>
            {
                entity.HasKey(e => e.IdFour);

                entity.ToTable("fournisseur");

                entity.Property(e => e.IdFour)
                    .ValueGeneratedNever()
                    .HasColumnName("id_four");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("name");
            });

            modelBuilder.Entity<ProduitFacture>(entity =>
            {
                entity.HasKey(e => new { e.IdFact, e.IdArt });

                entity.ToTable("produit_facture");

                entity.Property(e => e.IdFact).HasColumnName("id_fact");

                entity.Property(e => e.IdArt).HasColumnName("id_art");

                entity.Property(e => e.Qte).HasColumnName("qte");

                entity.HasOne(d => d.IdArtNavigation)
                    .WithMany(p => p.ProduitFactures)
                    .HasForeignKey(d => d.IdArt)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_produit_facture_article");

             
            });

            modelBuilder.Entity<Monetisation>(entity =>
            {
                entity.HasKey(e => e.Id);

                entity.ToTable("monetisation");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("id");

                entity.Property(e => e.DateMon)
                    .HasColumnType("date")
                    .HasColumnName("date_mon");

                

                entity.Property(e => e.Montant).HasColumnName("montant");

              
            });

            modelBuilder.Entity<Vendeur>(entity =>
            {
                entity.HasKey(e => e.IdVendeur);

                entity.ToTable("vendeurs");

                entity.Property(e => e.IdVendeur)
                    .ValueGeneratedNever()
                    .HasColumnName("id_vendeur");

                entity.Property(e => e.Fullname)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("fullname");

                entity.Property(e => e.Mdp)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("mdp");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
