﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace WebApplication4.Models
{
    public partial class Facture
    {
        public Facture()
        {
            ProduitFactures = new HashSet<ProduitFacture>();
        }
        [Required]
        public int IdFact { get; set; }
        [Required]
        public DateTime DateFact { get; set; }
        [Required]
        public float Total { get; set; }
        
        [Required]
        public int IdClt { get; set; }
        [Required]
        public int IdVendeur { get; set; }

        public virtual Client IdCltNavigation { get; set; }
        public virtual Vendeur IdVendeurNavigation { get; set; }
        public virtual ICollection<ProduitFacture> ProduitFactures { get; set; }
    }
}
