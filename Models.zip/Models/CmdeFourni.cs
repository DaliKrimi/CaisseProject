﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebApplication4.Models
{
    public partial class CmdeFourni
    {
        [Required]
        public int IdCmd { get; set; }
        [Required]
        public decimal Qte { get; set; }
        [Required]
        public int IdFour { get; set; }
        [Required]
        public int IdArt { get; set; }
        public virtual Fournisseur IdFourNavigation { get; set; }
    }
}
