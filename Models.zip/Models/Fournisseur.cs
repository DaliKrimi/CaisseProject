﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace WebApplication4.Models
{
    public partial class Fournisseur
    {
        public Fournisseur()
        {
            CmdeFournis = new HashSet<CmdeFourni>();
        }
        [Required]
        public int IdFour { get; set; }
        [Required]
        public string Name { get; set; }

        public virtual ICollection<CmdeFourni> CmdeFournis { get; set; }
    }
}
