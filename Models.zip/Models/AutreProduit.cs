﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication4.Models
{
    public class AutreProduit
    {
        [Required]
        public string  Nom { get; set; }
        [Required]
        public double  QteQisp { get; set; }
        [Required]
        public string  UniteMesure { get; set; }
        [Required]
        public double  Prix { get; set; }
        public double  Remise { get; set; }
    }
}
