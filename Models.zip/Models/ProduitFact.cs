﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication4.Models
{
    public class ProduitFact
    {
        public int IdArt { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public DateTime DateExp { get; set; }
        [Required]
        public int QteDisp { get; set; }
        [Required]
        public int IdCat { get; set; }
        [Required]
        public double Prix { get; set; }
        public double Remise { get; set; }
        [Required]
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public double  PrixTot { get; set; }
    }


}
