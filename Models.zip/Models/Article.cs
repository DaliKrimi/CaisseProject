﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace WebApplication4.Models
{
    public partial class Article
    {
        public Article()
        {
            ProduitFactures = new HashSet<ProduitFacture>();
        }
       
        public int IdArt { get; set; }
        [Required ]
        public string Name { get; set; }
        [Required]
        public DateTime DateExp { get; set; }
        [Required]
        public int QteDisp { get; set; }
       
        [Required]
        public int IdCat { get; set; }
        [Required]
        public double Prix { get; set; }
        public double Remise { get; set; }
        public virtual Categorie IdCatNavigation { get; set; }
        public virtual ICollection<ProduitFacture> ProduitFactures { get; set; }
       
    }
}
