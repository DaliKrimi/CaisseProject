﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace WebApplication4.Models
{
    public partial class Categorie
    {
        public Categorie()
        {
            Articles = new HashSet<Article>();
        }
        [Required]
        public int IdCat { get; set; }
        [Required]
        public string Designation { get; set; }
        public virtual ICollection<Article> Articles { get; set; }
    }
}
