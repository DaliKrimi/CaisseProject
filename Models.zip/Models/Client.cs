﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace WebApplication4.Models
{
    public partial class Client
    {
        public Client()
        {
            Factures = new HashSet<Facture>();
        }
        [Required]
        public int IdClt { get; set; }
        [Required]
        public string Firstname { get; set; }
        [Required]
        public string Lastname { get; set; }
        public int? NumCarte { get; set; }

        public virtual ICollection<Facture> Factures { get; set; }
    }
}
