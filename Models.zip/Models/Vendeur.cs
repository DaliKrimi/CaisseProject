﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace WebApplication4.Models
{
    public partial class Vendeur
    {
        public Vendeur()
        {
            Factures = new HashSet<Facture>();
        }
        [Required]
        public int IdVendeur { get; set; }
        [Required]
        public string Fullname { get; set; }
        [Required]
        public string Mdp { get; set; }

        public virtual ICollection<Facture> Factures { get; set; }
    }
}
