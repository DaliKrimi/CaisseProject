﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace WebApplication4.Models
{
    public partial class ProduitFacture
    {
        [Required]
        public int IdFact { get; set; }
        [Required]
        public int IdArt { get; set; }
        [Required]
        public int Qte { get; set; }

        public virtual Article IdArtNavigation { get; set; }
        public virtual Facture IdFactNavigation { get; set; }
    }
}
