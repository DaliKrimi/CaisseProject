﻿namespace ServiceProviderServiceExtensions.Database
{
    internal class EFProvider
    {
        internal class DataContext
        {
        }
    }
}