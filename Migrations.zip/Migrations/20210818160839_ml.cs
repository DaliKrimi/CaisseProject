﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApplication4.Migrations
{
    public partial class ml : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_cmde_fourni_categorie",
                table: "cmde_fourni");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Monetisations",
                table: "Monetisations");

            migrationBuilder.RenameTable(
                name: "Monetisations",
                newName: "monetisation");

            migrationBuilder.RenameColumn(
                name: "id_cat",
                table: "cmde_fourni",
                newName: "id_art");

            migrationBuilder.RenameIndex(
                name: "IX_cmde_fourni_id_cat",
                table: "cmde_fourni",
                newName: "IX_cmde_fourni_id_art");

            migrationBuilder.RenameColumn(
                name: "Montant",
                table: "monetisation",
                newName: "montant");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "monetisation",
                newName: "id");

            migrationBuilder.RenameColumn(
                name: "DateMon",
                table: "monetisation",
                newName: "date_mon");

           

            migrationBuilder.AlterColumn<int>(
                name: "id",
                table: "monetisation",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int")
                .OldAnnotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AlterColumn<DateTime>(
                name: "date_mon",
                table: "monetisation",
                type: "date",
                nullable: false,
                oldClrType: typeof(DateTime),
                oldType: "datetime2");

            migrationBuilder.AddPrimaryKey(
                name: "PK_monetisation",
                table: "monetisation",
                column: "id");

            migrationBuilder.CreateIndex(
                name: "IX_cmde_fourni_CategorieIdCat",
                table: "cmde_fourni",
                column: "CategorieIdCat");

            migrationBuilder.AddForeignKey(
                name: "FK_cmde_fourni_categorie",
                table: "cmde_fourni",
                column: "id_art",
                principalTable: "article",
                principalColumn: "id_art",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_cmde_fourni_categorie_CategorieIdCat",
                table: "cmde_fourni",
                column: "CategorieIdCat",
                principalTable: "categorie",
                principalColumn: "id_cat",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_cmde_fourni_categorie",
                table: "cmde_fourni");

            migrationBuilder.DropForeignKey(
                name: "FK_cmde_fourni_categorie_CategorieIdCat",
                table: "cmde_fourni");

            migrationBuilder.DropIndex(
                name: "IX_cmde_fourni_CategorieIdCat",
                table: "cmde_fourni");

            migrationBuilder.DropPrimaryKey(
                name: "PK_monetisation",
                table: "monetisation");

            migrationBuilder.DropColumn(
                name: "CategorieIdCat",
                table: "cmde_fourni");

            migrationBuilder.RenameTable(
                name: "monetisation",
                newName: "Monetisations");

            migrationBuilder.RenameColumn(
                name: "id_art",
                table: "cmde_fourni",
                newName: "id_cat");

            migrationBuilder.RenameIndex(
                name: "IX_cmde_fourni_id_art",
                table: "cmde_fourni",
                newName: "IX_cmde_fourni_id_cat");

            migrationBuilder.RenameColumn(
                name: "montant",
                table: "Monetisations",
                newName: "Montant");

            migrationBuilder.RenameColumn(
                name: "id",
                table: "Monetisations",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "date_mon",
                table: "Monetisations",
                newName: "DateMon");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "Monetisations",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int")
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AlterColumn<DateTime>(
                name: "DateMon",
                table: "Monetisations",
                type: "datetime2",
                nullable: false,
                oldClrType: typeof(DateTime),
                oldType: "date");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Monetisations",
                table: "Monetisations",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_cmde_fourni_categorie",
                table: "cmde_fourni",
                column: "id_cat",
                principalTable: "categorie",
                principalColumn: "id_cat",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
