﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApplication4.Migrations
{
    public partial class updatess : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_produit_facture_facture",
                table: "produit_facture");

            migrationBuilder.CreateTable(
                name: "ProduitFact",
                columns: table => new
                {
                    id_art = table.Column<int>(type: "int", nullable: false),
                    name = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    date_exp = table.Column<DateTime>(type: "date", nullable: false),
                    qte_disp = table.Column<int>(type: "int", nullable: false),
                    id_cat = table.Column<int>(type: "int", nullable: false),
                    Prix = table.Column<double>(type: "float", nullable: false),
                    remise = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProduitFact", x => x.id_art);
                });

            migrationBuilder.AddForeignKey(
                name: "FK_produit_facture_facture_id_fact",
                table: "produit_facture",
                column: "id_fact",
                principalTable: "facture",
                principalColumn: "id_fact",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_produit_facture_facture_id_fact",
                table: "produit_facture");

            migrationBuilder.DropTable(
                name: "ProduitFact");

            migrationBuilder.AddForeignKey(
                name: "FK_produit_facture_facture",
                table: "produit_facture",
                column: "id_fact",
                principalTable: "facture",
                principalColumn: "id_fact",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
