﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApplication4.Migrations
{
    public partial class addcomponnet : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "admin",
                columns: table => new
                {
                    username = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    password = table.Column<string>(type: "varchar(max)", unicode: false, nullable: false),
                    RememberMe = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "categorie",
                columns: table => new
                {
                    id_cat = table.Column<int>(type: "int", nullable: false),
                    designation = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_categorie", x => x.id_cat);
                });

            migrationBuilder.CreateTable(
                name: "client",
                columns: table => new
                {
                    Id_clt = table.Column<int>(type: "int", nullable: false),
                    firstname = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    lastname = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    num_carte = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__client__56642C08DE20934E", x => x.Id_clt);
                });

            migrationBuilder.CreateTable(
                name: "fournisseur",
                columns: table => new
                {
                    id_four = table.Column<int>(type: "int", nullable: false),
                    name = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_fournisseur", x => x.id_four);
                });

            migrationBuilder.CreateTable(
                name: "vendeurs",
                columns: table => new
                {
                    id_vendeur = table.Column<int>(type: "int", nullable: false),
                    fullname = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    mdp = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_vendeurs", x => x.id_vendeur);
                });

            migrationBuilder.CreateTable(
                name: "article",
                columns: table => new
                {
                    id_art = table.Column<int>(type: "int", nullable: false),
                    name = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    date_exp = table.Column<DateTime>(type: "date", nullable: false),
                    qte_disp = table.Column<int>(type: "int", nullable: false),
                    id_cat = table.Column<int>(type: "int", nullable: false),
                    Prix = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_article", x => x.id_art);
                    table.ForeignKey(
                        name: "FK_article_categorie",
                        column: x => x.id_cat,
                        principalTable: "categorie",
                        principalColumn: "id_cat",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "cmde_fourni",
                columns: table => new
                {
                    id_cmd = table.Column<int>(type: "int", nullable: false),
                    qte = table.Column<decimal>(type: "numeric(18,0)", nullable: false),
                    id_cat = table.Column<int>(type: "int", nullable: false),
                    id_four = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cmde_fourni", x => x.id_cmd);
                    table.ForeignKey(
                        name: "FK_cmde_fourni_categorie",
                        column: x => x.id_cat,
                        principalTable: "categorie",
                        principalColumn: "id_cat",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_cmde_fourni_fournisseur",
                        column: x => x.id_four,
                        principalTable: "fournisseur",
                        principalColumn: "id_four",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "facture",
                columns: table => new
                {
                    id_fact = table.Column<int>(type: "int", nullable: false),
                    date_fact = table.Column<DateTime>(type: "date", nullable: false),
                    total = table.Column<float>(type: "real", nullable: false),
                    remise = table.Column<float>(type: "real", nullable: true),
                    Id_clt = table.Column<int>(type: "int", nullable: false),
                    id_vendeur = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_facture", x => x.id_fact);
                    table.ForeignKey(
                        name: "FK_facture_client",
                        column: x => x.Id_clt,
                        principalTable: "client",
                        principalColumn: "Id_clt",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_facture_vendeurs",
                        column: x => x.id_vendeur,
                        principalTable: "vendeurs",
                        principalColumn: "id_vendeur",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "produit_facture",
                columns: table => new
                {
                    id_fact = table.Column<int>(type: "int", nullable: false),
                    id_art = table.Column<int>(type: "int", nullable: false),
                    qte = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_produit_facture", x => new { x.id_fact, x.id_art });
                    table.ForeignKey(
                        name: "FK_produit_facture_article",
                        column: x => x.id_art,
                        principalTable: "article",
                        principalColumn: "id_art",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_produit_facture_facture",
                        column: x => x.id_fact,
                        principalTable: "facture",
                        principalColumn: "id_fact",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_article_id_cat",
                table: "article",
                column: "id_cat");

            migrationBuilder.CreateIndex(
                name: "IX_cmde_fourni_id_cat",
                table: "cmde_fourni",
                column: "id_cat");

            migrationBuilder.CreateIndex(
                name: "IX_cmde_fourni_id_four",
                table: "cmde_fourni",
                column: "id_four");

            migrationBuilder.CreateIndex(
                name: "IX_facture_Id_clt",
                table: "facture",
                column: "Id_clt");

            migrationBuilder.CreateIndex(
                name: "IX_facture_id_vendeur",
                table: "facture",
                column: "id_vendeur");

            migrationBuilder.CreateIndex(
                name: "IX_produit_facture_id_art",
                table: "produit_facture",
                column: "id_art");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "admin");

            migrationBuilder.DropTable(
                name: "cmde_fourni");

            migrationBuilder.DropTable(
                name: "produit_facture");

            migrationBuilder.DropTable(
                name: "fournisseur");

            migrationBuilder.DropTable(
                name: "article");

            migrationBuilder.DropTable(
                name: "facture");

            migrationBuilder.DropTable(
                name: "categorie");

            migrationBuilder.DropTable(
                name: "client");

            migrationBuilder.DropTable(
                name: "vendeurs");
        }
    }
}
