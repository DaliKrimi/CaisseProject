﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApplication4.Migrations
{
    public partial class migg : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "remise",
                table: "facture");

            migrationBuilder.AddColumn<double>(
                name: "remise",
                table: "article",
                type: "float",
                nullable: false,
                defaultValue: 0.0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "remise",
                table: "article");

            migrationBuilder.AddColumn<float>(
                name: "remise",
                table: "facture",
                type: "real",
                nullable: true);
        }
    }
}
